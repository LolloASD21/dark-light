[![Netlify Status](https://api.netlify.com/api/v1/badges/96dc733b-a1e1-4453-a298-b1d0fb2b9cb4/deploy-status)](https://app.netlify.com/sites/vite-cssnext/deploys)

[PostCSS preset-env](https://preset-env.netlify.app/) layer on top of the vanilla [@vite/create-vite](https://github.com/vitejs/vite/tree/main/packages/create-vite)