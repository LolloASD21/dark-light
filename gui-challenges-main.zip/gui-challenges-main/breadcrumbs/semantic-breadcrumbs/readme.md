This example enhances the semantic of the breadcrumbs (in the parent folder) demo adding HTML5 microdata and improved HTML syntax
